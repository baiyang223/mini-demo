let DURATION = 180000 //录音时长,毫秒
let VOLUME = 0.2  //音频播放音量0~1

const profile = {
    duration: DURATION,
    volume: VOLUME
};

export default profile
